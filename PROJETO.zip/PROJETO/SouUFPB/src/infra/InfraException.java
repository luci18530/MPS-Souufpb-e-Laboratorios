package infra;

public class InfraException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4176717944228612029L;

	public InfraException(String message) {
		super(message);
	}

}
